package com.microservicesfullstack.eureka.microservicioeureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
