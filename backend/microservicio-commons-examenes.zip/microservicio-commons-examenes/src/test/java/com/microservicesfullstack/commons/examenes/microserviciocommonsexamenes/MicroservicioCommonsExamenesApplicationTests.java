package com.microservicesfullstack.commons.examenes.microserviciocommonsexamenes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioCommonsExamenesApplicationTests {

	@Test
	void contextLoads() {
	}

}
