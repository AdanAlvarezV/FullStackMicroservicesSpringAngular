package com.microservicesfullstack.commons.examenes.microserviciocommonsexamenes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioCommonsExamenesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioCommonsExamenesApplication.class, args);
	}

}
