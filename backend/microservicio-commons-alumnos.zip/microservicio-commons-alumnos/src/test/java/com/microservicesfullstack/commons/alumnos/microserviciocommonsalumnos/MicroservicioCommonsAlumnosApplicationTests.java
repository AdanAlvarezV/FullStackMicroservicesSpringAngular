package com.microservicesfullstack.commons.alumnos.microserviciocommonsalumnos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioCommonsAlumnosApplicationTests {

	@Test
	void contextLoads() {
	}

}
