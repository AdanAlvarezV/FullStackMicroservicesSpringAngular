package com.microservicesfullstack.commoons.microserviciocommons;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioCommonsApplicationTests {

	@Test
	void contextLoads() {
	}

}
