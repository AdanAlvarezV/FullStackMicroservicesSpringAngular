package com.microservicesfullstack.usuarios.microserviciousuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
