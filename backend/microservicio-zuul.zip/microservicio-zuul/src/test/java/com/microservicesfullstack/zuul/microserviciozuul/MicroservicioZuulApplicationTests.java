package com.microservicesfullstack.zuul.microserviciozuul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioZuulApplicationTests {

	@Test
	void contextLoads() {
	}

}
