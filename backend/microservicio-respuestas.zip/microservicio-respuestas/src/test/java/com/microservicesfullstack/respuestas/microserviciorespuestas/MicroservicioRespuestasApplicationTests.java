package com.microservicesfullstack.respuestas.microserviciorespuestas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioRespuestasApplicationTests {

	@Test
	void contextLoads() {
	}

}
