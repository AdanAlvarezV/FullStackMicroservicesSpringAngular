package com.microservicesfullstack.cursos.microserviciocursos.microserviciogateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
