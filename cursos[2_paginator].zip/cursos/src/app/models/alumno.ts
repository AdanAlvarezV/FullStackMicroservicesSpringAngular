export class Alumno {
    id: number;
    nombre: string;
    apellido: string;
    email:string;
    createAt: string;
    fotoHashCode: number;
}
